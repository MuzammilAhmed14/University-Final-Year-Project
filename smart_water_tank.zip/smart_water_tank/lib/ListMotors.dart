import 'dart:convert';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ListMotors extends StatefulWidget {
  const ListMotors({Key? key}) : super(key: key);

  @override
  State<ListMotors> createState() => _ListMotorsState();
}

class _ListMotorsState extends State<ListMotors> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List of Motors"),
        backgroundColor: Colors.blue,
        elevation: 10.0,
      ),
      body: FutureBuilder(
        future: getMotors(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.hasData && !snapshot.hasError) {
            List list = snapshot.data as List;
            return ListView.builder(
                itemCount: list.length,
                itemBuilder: (context, index) {
                  return Container(
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Image.asset(
                              "assets/images/motor.png",
                              scale: 6,
                            ),
                            Text(
                              list[index]['motorNo'],
                              style: TextStyle(fontSize: 16.0),
                            )
                          ],
                        ),
                        Divider(),
                      ],
                    ),
                  );
                });
          } else {
            return Center(
              child: Text("No Motor record are found for this user"),
            );
          }
        },
      ),
    );
  }

  Future<void> getMotors() async {
    Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
    final SharedPreferences prefs = await _prefs;
    String email = prefs.getString("email")!;
    var url = "http://admin.easylife4y.com/Api/getMotors.php";
    var response = await http.post(Uri.parse(url), body: {"email": email});
    var data = jsonDecode(response.body);
    return data;
  }
}
