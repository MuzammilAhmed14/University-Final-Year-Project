import 'dart:convert';

import 'package:ndialog/ndialog.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smart_water_tank/screens/sign_up/components/sign_up_form.dart';
import 'package:smart_water_tank/screens/sign_up/sign_up_screen.dart';
import '../../../constants.dart';
import '../../../size_config.dart';
import '../../../components/default_button.dart';
import '../../../components/custom_suffix_icon.dart';
import '../../login_success/login_success_screen.dart';
import '../../forgot_password/forgot_password_screen.dart';
import 'package:http/http.dart' as http;

class SignForm extends StatefulWidget {
  @override
  _SignFormState createState() => _SignFormState();
}

class _SignFormState extends State<SignForm> {
  final _formKey = GlobalKey<FormState>();
  final List<String> errors = [];

  late String email, password;

  bool firstSubmit = false;
  bool remember = false;

  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    ProgressDialog dialog = new ProgressDialog(context,
        title: Text("Sign In"), message: Text("Please wait..."));
    return Form(
      key: _formKey,
      child: Column(
        children: [
          buildEmailFormField(),
          SizedBox(height: getProportionateScreenHeight(30)),
          buildPasswordFormField(),
          SizedBox(height: getProportionateScreenHeight(30)),
          Row(
            children: [
              Checkbox(
                value: remember,
                activeColor: kPrimaryColor,
                onChanged: (value) => setState(() => remember = value!),
              ),
              Text("Remember me"),
              Spacer(),
            ],
          ),
          SizedBox(height: getProportionateScreenHeight(30)),
          ElevatedButton(
            onPressed: () async {
              Future<SharedPreferences> _prefs =
                  SharedPreferences.getInstance();
              final SharedPreferences prefs = await _prefs;
              dialog.show();
              String email = emailController.text.trim();
              String password = passwordController.text.trim();

              var url = "http://admin.easylife4y.com/Api/login.php";
              var response = await http.post(Uri.parse(url),
                  body: {"email": email, "password": password});
              var data = jsonDecode(response.body);
              if (data == "success") {
                prefs.setString("email", email);
                dialog.dismiss();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      backgroundColor: Colors.black,
                      content: Text(
                        "Login Successfully",
                        style: TextStyle(color: Colors.white),
                      )),
                );
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => LoginSuccessScreen()));
              } else {
                dialog.dismiss();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      backgroundColor: Colors.black,
                      content: Text(
                        "Login Failed",
                        style: TextStyle(color: Colors.white),
                      )),
                );
              }
            },
            child: Text(
              "Continue",
              style: TextStyle(
                fontSize: getProportionateScreenWidth(18),
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(kPrimaryColor),
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              minimumSize: MaterialStateProperty.all(
                Size(
                  getProportionateScreenWidth(double.infinity),
                  getProportionateScreenHeight(56),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  TextFormField buildPasswordFormField() {
    return TextFormField(
      controller: passwordController,
      onSaved: (newPassword) => this.password = newPassword!,
      onChanged: (password) {
        if (firstSubmit) _formKey.currentState!.validate();
      },
      validator: (password) {
        if (password!.isEmpty) {
          return kPassNullError;
        } else if (password.isNotEmpty && password.length <= 7) {
          return kShortPassError;
        }

        return null;
      },
      decoration: InputDecoration(
        labelText: "Password",
        hintText: "Enter your password",
        suffixIcon: CustomSuffixIcon(iconPath: "assets/icons/Lock.svg"),
      ),
      obscureText: true,
    );
  }

  TextFormField buildEmailFormField() {
    return TextFormField(
      controller: emailController,
      onSaved: (newEmail) => this.email = newEmail!,
      onChanged: (email) {
        if (firstSubmit) _formKey.currentState!.validate();
      },
      validator: (email) {
        if (email!.isEmpty) {
          return kEmailNullError;
        } else if (email.isNotEmpty && !emailValidatorRegExp.hasMatch(email)) {
          return kInvalidEmailError;
        }

        return null;
      },
      decoration: InputDecoration(
        labelText: "Email",
        hintText: "Enter your email",
        suffixIcon: CustomSuffixIcon(iconPath: "assets/icons/Mail.svg"),
      ),
      keyboardType: TextInputType.emailAddress,
    );
  }
}
