import 'package:flutter/material.dart';
import 'package:smart_water_tank/components/default_button.dart';
import 'package:smart_water_tank/constants.dart';
import 'package:smart_water_tank/dashboard.dart';
import 'package:smart_water_tank/gridDashboard.dart';
import 'package:smart_water_tank/screens/home/home_screen.dart';
import 'package:smart_water_tank/size_config.dart';

import '../../../size_config.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: SizeConfig.screenHeight * 0.04),
        Image.asset(
          'assets/images/success.png',
          height: SizeConfig.screenHeight * 0.4,
        ),
        SizedBox(height: SizeConfig.screenHeight * 0.08),
        Text(
          "Login Success",
          style: headingStyle,
        ),
        Spacer(),
        SizedBox(
            width: SizeConfig.screenWidth * .6,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Dashboard()));
              },
              child: Text(
                "Back to home",
                style: TextStyle(
                  fontSize: getProportionateScreenWidth(18),
                ),
              ),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(kPrimaryColor),
                shape: MaterialStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                minimumSize: MaterialStateProperty.all(
                  Size(
                    getProportionateScreenWidth(double.infinity),
                    getProportionateScreenHeight(56),
                  ),
                ),
              ),
            )),
        Spacer(),
      ],
    );
  }
}
