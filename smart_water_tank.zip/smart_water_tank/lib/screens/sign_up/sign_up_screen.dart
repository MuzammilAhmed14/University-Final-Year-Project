import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:ndialog/ndialog.dart';
import 'package:smart_water_tank/constants.dart';
import 'package:smart_water_tank/screens/sign_in/components/sign_in_form.dart';
import 'package:smart_water_tank/screens/sign_in/sign_in_screen.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController nameController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    ProgressDialog dialog = new ProgressDialog(context,
        title: Text("Sign up"), message: Text("please wait ..."));
    return Scaffold(
      appBar: AppBar(
        title: Text(
            "Sign in with your email and password\nor continue with social media"),
      ),
      body: Card(
        child: Padding(
          padding: const EdgeInsets.all(11.0),
          child: Container(
            child: Column(
              children: [
                SizedBox(
                  height: 25.0,
                ),
                Text(
                  "Wellcome Back",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 30.0,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 6.0,
                ),
                Text("Sign Up for Social Media"),
                SizedBox(
                  height: 70.0,
                ),
                TextFormField(
                  keyboardType: TextInputType.name,
                  controller: nameController,
                  decoration: InputDecoration(
                      label: Text("User Name"),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      )),
                ),
                SizedBox(
                  height: 15.0,
                ),
                TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  controller: emailController,
                  decoration: InputDecoration(
                      label: Text("Email Address"),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      )),
                ),
                SizedBox(
                  height: 15.0,
                ),
                TextFormField(
                  keyboardType: TextInputType.visiblePassword,
                  obscureText: true,
                  controller: passwordController,
                  decoration: InputDecoration(
                      label: Text("Password"),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      )),
                ),
                SizedBox(
                  height: 20.0,
                ),
                ElevatedButton(
                    onPressed: () async {
                      dialog.show();
                      String email = emailController.text.trim();
                      String password = passwordController.text.trim();
                      String name = nameController.text.trim();

                      var url =
                          "http://admin.easylife4y.com/Api/registration.php";
                      var response = await http.post(Uri.parse(url), body: {
                        "name": name,
                        "email": email,
                        "password": password
                      });
                      var data = jsonDecode(response.body);
                      if (data == "success") {
                        dialog.dismiss();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              backgroundColor: Colors.black,
                              content: Text(
                                "Login Successfully",
                                style: TextStyle(color: Colors.white),
                              )),
                        );
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SignForm()));
                      } else {
                        dialog.dismiss();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              backgroundColor: Colors.black,
                              content: Text(
                                "Login Failed",
                                style: TextStyle(color: Colors.white),
                              )),
                        );
                      }
                    },
                    child: Text("Sign Up"))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
