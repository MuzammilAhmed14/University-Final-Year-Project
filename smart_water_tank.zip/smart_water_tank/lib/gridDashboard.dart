import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smart_water_tank/ListMotors.dart';
import 'package:smart_water_tank/screens/sign_in/sign_in_screen.dart';

class GridDashboard extends StatelessWidget {
  Items item1 = new Items(
      id: 1,
      title: "Unit Consumptions",
      subtitle: "Electricity Used",
      event: "",
      img: "assets/images/electrical.png");

  Items item2 = new Items(
    id: 2,
    title: "Motors",
    subtitle: "Smart Water Motors",
    event: "",
    img: "assets/images/motor.png",
  );
  Items item3 = new Items(
    id: 3,
    title: "Locations",
    subtitle: "Lucy Mao going to Office",
    event: "",
    img: "assets/images/map.png",
  );
  Items item4 = new Items(
    id: 4,
    title: "About",
    subtitle: "About the company",
    event: "",
    img: "assets/images/festival.png",
  );

  Items item6 = new Items(
    id: 5,
    title: "Logout",
    subtitle: "",
    event: "",
    img: "assets/images/setting.png",
  );

  @override
  Widget build(BuildContext context) {
    List<Items> myList = [item1, item2, item3, item4, item6];
    var color = Colors.blue;
    return Flexible(
      child: GridView.count(
        childAspectRatio: 1.0,
        padding: EdgeInsets.only(left: 16, right: 16),
        crossAxisCount: 2,
        crossAxisSpacing: 18,
        mainAxisSpacing: 18,
        children: myList.map((data) {
          return InkWell(
            onTap: () {
              if (data.id == 2) {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ListMotors()));
              } else if (data.id == 5) {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SignInScreen()));
              }
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.asset(data.img, width: 42),
                  SizedBox(height: 14),
                  Text(
                    data.title,
                    style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    data.subtitle,
                    style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                        color: Colors.white38,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 14),
                  Text(
                    data.event,
                    style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class Items {
  int id;
  String title;
  String subtitle;
  String event;
  String img;
  Items(
      {required this.id,
      required this.title,
      required this.subtitle,
      required this.event,
      required this.img});
}
